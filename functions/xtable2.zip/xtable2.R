# ======================================
#      Project: Tabling functions
#      Casey Crisman-Cox
#      Useful Functions
#      Tabling.R
# ======================================
#######Dependencies#####
if("xtable" %in% installed.packages()){
        library(xtable)
  }else{
        install.packages("xtable")
        library(xtable)
}
if("stringr" %in% installed.packages()){
  library(stringr)
}else{
  install.packages("stringr")
  library(stringr)
}



mod.sum<-function(..., apsr=FALSE){  ##Function to add in LogLik and N to xtable
mod<-list(...)
out<-NULL
if(apsr==FALSE){
     mod<-mod[[1]]
     ##Works on maxLik, lm, glm, game, and surv
     if("maxLik" %in% class(mod)){ ##Check if the class is maxLik
          out<-paste("\\hline ", 
                     "Log $L$ & \\multicolumn{4}{c}{",format(logLik(mod)), "}\\\\\n",
                     "$N$ & \\multicolumn{4}{c}{", nrow(mod$gradientObs), "}\\\\\n", 
                     sep="") ##Creates two rows which we'll add to xtable
     }
     if("lm" == class(mod)[1]){
          out<-paste("\\hline ",
                     "adj. R$^2$& \\multicolumn{4}{c}{", format(summary(mod)$adj.r.squared),
                     "}\\\\\n",
                     "$N$ & \\multicolumn{4}{c}{", nrow(mod$model), "}\\\\\n",
                     sep="") ##Same as above
     }
     
     if("glm" == class(mod)[1]  | "game" %in% class(mod) 
        |"polr" %in% class(mod)){
          out<-paste("\\hline ",
                     "Log $L$ & \\multicolumn{4}{c}{",format(logLik(mod)), "}\\\\\n",
                     "$N$ & \\multicolumn{4}{c}{", nrow(mod$model), "}\\\\\n", 
                     sep="") ##Creates two rows which we'll add to xtable
     }
     out<-list(out=out, 
               length=length(unique(names(coef(mod)))))
}else{
    out.L<-paste("\\hline ", 
                 "Log $L$")
    out.R<-paste("adj. R$^2$")
    out.N<-paste("$N$")
    for(i in 1:length(mod)){
         mod.i<-mod[[i]]
         ##Works on maxLik, lm, glm, game, and surv
         if("maxLik" %in% class(mod.i)){ ##Check if the class is maxLik
              out.L<-str_c(out.L,
                           paste(" & ",
                                 format(logLik(mod.i))))
              out.R<-str_c(out.R, " & ")
              out.N<- str_c(out.N,
                            paste(" & ", nrow(mod.i$gradientObs)))
         }
         if("lm" == class(mod.i)[1]){
           out.L<-str_c(out.L, " & ")
           out.R<-str_c(out.R,
                        paste(" & ", 
                              format(summary(mod.i)$adj.r.squared)))
           out.N<-str_c(out.N,
                        paste("& ", nrow(mod.i$model)))
         }
         
         if("glm" == class(mod.i)[1]  | "game" %in% class(mod.i) 
            |"polr" %in% class(mod.i)){
           out.L<-str_c(out.L,
                        paste(" & ",
                              format(logLik(mod.i))))
           out.R<-str_c(out.R, " & ")
           out.N<- str_c(out.N,
                         paste(" & ", nrow(mod.i$model)))
         }
    }     
    ifelse(any("lm" %in% lapply(mod, class)),
           out<-str_c(out.L, "\\\\\n", out.R, "\\\\\n", out.N, "\\\\\n"),
           out<-str_c(out.L, "\\\\\n", out.N, "\\\\\n"))
    out<-list(out=out, 
              length=2*length(unique(unlist(lapply(mod, 
                                                   function(x){names(coef(x))})))))
}
if(is.null(out)){stop("Object class not supported")}
return(out)
}

##handrolled Coeftest
coeftest2<-function(beta, sd){
     z<-beta/sd
     p.value<-pnorm(abs(z), lower.tail=FALSE)*2
     results<-cbind(beta, sd,z, p.value)
     colnames(results)<-c("Estimate",
                          "Std. Error",
                          "Z Value",
                          "Pr(|z|)")
     return(results)
}

##A wrapper for xtable to allow stackign multiple models and inputing 
##Bootstrapped standard errors
xtable.2<-function(mod.list, 
                   se=NULL, 
                   coef=FALSE,
                   apsr=FALSE, 
                   stars="default", 
                   model.names=NULL,
                   caption=NULL,
                   label=NULL, 
                   align=NULL, 
                   digits=2,
                   ...){
     if(is.null(model.names)){
          model.names<-paste("Model", 1:nrow(summary(mod.list)))
     }
     model.names<-paste("\\multicolumn{1}{c}{", model.names, "}")
     if(coef==FALSE){
       coef.list<-lapply(mod.list, coef)
     }else{coef.list<-mod.list}
     output<-data.frame()
     for(i in 1:nrow(summary(mod.list))){
          
          if(!is.null(se)){
               table<-coeftest2(coef.list[[i]], se[[i]])
          }else{
               table<-coeftest2(coef.list[[i]], 
                                sqrt(diag(vcov(mod.list[[i]]))))
          }
          
          if(apsr==TRUE){
               a.table<-data.frame()
               for(j in 1:nrow(table)){
                    temp<-table[j, 1:2]
                    temp<-t(t(temp))
                    temp<-format(temp, digits=digits, nsmall=digits, drop0trailing=FALSE)
                    temp<-str_trim(temp)
                    temp[2,]<-paste("(",
                                    temp[2,],
                                    ")", sep="")
                    if(stars=="default"){
                         if(table[j, 4]<0.05){
                              temp[1,]<- paste(temp[1,] ,"$^*$", sep="")
                         }
                    }     
                    if(stars=="all"){
                         if(table[j, 4]<0.1 & table[j, 4]>0.05){
                              temp[1,]<- paste(temp[1,] ,"$^\\dagger$", sep="")
                         }
                         if(table[j, 4]<0.05 & table[j, 4]>0.01){
                              temp[1,]<- paste(temp[1,] ,"$^*$", sep="")
                         }
                         if(table[j, 4]<0.01& table[j, 4]>0.001){
                              temp[1,]<- paste(temp[1,] ,"$^{**}$", sep="")
                         }
                         if(table[j, 4]<0.001){
                              temp[1,]<- paste(temp[1,] ,"$^{***}$", sep="")
                         }
                    }
                    row.names(temp)<-NULL
                    var.name<-row.names(table)[j]
                    colnames(temp)<-model.names[i]
                    row.names(temp)<-c(var.name, paste(var.name, ".se", sep=""))
                    a.table<-rbind(a.table, temp)  
               }
               if(i==1){
                    a.output<-a.table
                    ` `<-row.names(a.output)
                    row.names(a.output)<-NULL
                    a.output<-cbind(` `, a.output)
               }else{` `<-row.names(a.table)
                     row.names(a.table)<-NULL
                     a.table<-cbind(` `, a.table)
                    
                    
                    a.output<-merge(a.output, 
                                    a.table,
                                    by= " ",
                                    all=TRUE,
                                    sort=FALSE)                     
               }
               
          }else{
               ` `<-row.names(table)
               row.names(table)<-NULL
               table<-cbind.data.frame(` `, table)
               output<-rbind(output, table)
          }
     }
     if(apsr==TRUE){
          a.output$` `[str_detect(a.output$` `, ".se")]<-""
          output<-a.output
          
     }
     align<-ifelse(is.null(align),
                   ifelse(apsr==FALSE, 
                          str_c(rep("r", ncol(output)+1), collapse=""),
                          str_c(c("rl", rep("S", ncol(output)-1)), collapse="")),
                   align)
#      return(output)
     print(xtable(output,
                  caption=caption,
                  label=label, 
                  align=align, 
                  digits=digits),
           
           ...)
}
###Note this function requires 


#\usepackage{siunitx}
#Be in the preamble 
